import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import static java.lang.Math.ceil;
import static java.lang.Math.sqrt;

class car{
    int buying,maint,doors,persons,lug_boot,safety,class_value;
    int[] attribute_check;
    car(){
        buying=0; // 1=vhigh,2=high,3=med,4=low
        maint=0; //same as buying
        doors=0; //2,3,4,5=more
        persons=0; //2,4, 5=more
        lug_boot=0; //1=small,2=med, 3=big
        safety=0; //1=low,2=med,3=high
        class_value=0; //1=unacc,2=acc,3=good,4=vgood
        attribute_check=new int[6];
    }
}
class node{
    int attribute_id;
    double gain;
    boolean leaf;
    node(){
        attribute_id=0;
        gain=Double.MAX_VALUE;
        leaf=false;
    }
}
class tree{
    int attribute;
    boolean isLeaf; 
    List<tree> descendent;
    tree(){
        attribute=0;
        isLeaf=false;
        descendent=new ArrayList<>();
    }
}
public class Main {
    static int[] array;
    // static int[] attribute_order=new int[6];
    static int buy_value(String s){
        if(s.equalsIgnoreCase("vhigh")){
            return 1;
        }
        else if(s.equalsIgnoreCase("high")){
            return 2;
        }
        else if(s.equalsIgnoreCase("med")){
            return 3;
        }
        else if(s.equalsIgnoreCase("low")){
            return 4;
        }
        else
            return 0;
    }
    static int maint_value(String s){
        if(s.equalsIgnoreCase("vhigh")){
            return 1;
        }
        else if(s.equalsIgnoreCase("high")){
            return 2;
        }
        else if(s.equalsIgnoreCase("med")){
            return 3;
        }
        else if(s.equalsIgnoreCase("low")){
            return 4;
        }
        else
            return 0;
    }
    static int doors_value(String s){
        if(s.equalsIgnoreCase("2")){
            return 1;
        }
        else if(s.equalsIgnoreCase("3")){
            return 2;
        }
        else if(s.equalsIgnoreCase("4")){
            return 3;
        }
        else if(s.equalsIgnoreCase("5more")){
            return 4;
        }
        else
            return 0;
    }
    static int persons_value(String s){
        if(s.equalsIgnoreCase("2")){
            return 1;
        }
        else if(s.equalsIgnoreCase("4")){
            return 2;
        }
        else if(s.equalsIgnoreCase("more")){
            return 3;
        }
        else
            return 0;
    }
    static int lug_boot_value(String s){
        if(s.equalsIgnoreCase("small")){
            return 1;
        }
        else if(s.equalsIgnoreCase("med")){
            return 2;
        }
        else if(s.equalsIgnoreCase("big")){
            return 3;
        }
        else
            return 0;
    }
    static int safety_value(String s){
        if(s.equalsIgnoreCase("low")){
            return 1;
        }
        else if(s.equalsIgnoreCase("med")){
            return 2;
        }
        else if(s.equalsIgnoreCase("high")){
            return 3;
        }
        else
            return 0;
    }
    static int set_class_value(String s){
        if(s.equalsIgnoreCase("unacc")){
            return 1;
        }
        else if(s.equalsIgnoreCase("acc")){
            return 2;
        }
        else if(s.equalsIgnoreCase("good")){
            return 3;
        }
        else if(s.equalsIgnoreCase("vgood")){
            return 4;
        }
        return 0;
    }
    static double probability(int up,int down){
        return (double)up/down;
    }

    static double H(double num, double total){
        if(num==0 ) return 0;
        else return (num/total)*Math.log(num/total);
    }

    static double entropy(int unacc,int acc,int good,int vgood){
        double total=(unacc*1.0)+(acc*1.0)+(good*1.0)+(vgood*1.0);
        double ent=-H(unacc,total)-H(acc,total)-H(good,total)-H(vgood,total);
        return ent;
    }
    static double remainder_calculate(List<car> training_set,ArrayList[] bags,int iteration_count){
        int root=0;
        double remainder=0.0;
        int unacc=unacc_count(training_set);
        int acc=acc_count(training_set);
        int good=good_count(training_set);
        int vgood=vgood_count(training_set);
        int total=unacc+acc+good+vgood;
        double entropy=0;
        if(unacc==total || acc ==total || good==total || vgood==total){
            return 0.0;
        }
        else{
            double rem=0.0;
            for(int i=1;i<=iteration_count;i++){
                rem+=probability(bags[i].size(),training_set.size())*entropy(unacc_count(bags[i]),acc_count(bags[i]),good_count(bags[i]),vgood_count(bags[i]));
            }
            return rem;
        }
    }
    static double child_divide(List<car> training_set,int attr){
        int iteration_count;
        if(attr==1 || attr==2 || attr==3){
            iteration_count=4;
        }
        
        else{
            iteration_count=3;
        }
        ArrayList[] bags=new ArrayList[iteration_count+1];
        for(int r=0;r<=iteration_count;r++) {
            bags[r]=new ArrayList();
        }
        for(int i=1;i<=iteration_count;i++){
            for(int j=0;j<training_set.size();j++){
                if(attr==1){
                    if(training_set.get(j).buying==i)
//                        count[i]++;
                        bags[i].add(training_set.get(j));
                }

                else if(attr==2){
                    if(training_set.get(j).maint==i)
                        // count[i]++;
                        bags[i].add(training_set.get(j));
                }
                else if(attr==3){
                    if(training_set.get(j).doors==i){
                        bags[i].add(training_set.get(j));
                    }
                }
                else if(attr==4){
                    if(training_set.get(j).persons==i){
                        bags[i].add(training_set.get(j));
                    }
                }
                else if(attr==5){
                    if(training_set.get(j).lug_boot==i){
                        bags[i].add(training_set.get(j));
                    }
                }
                else if(attr==6){
                    if(training_set.get(j).safety==i){
                        bags[i].add(training_set.get(j));
                    }
                }
            }
            // System.out.println(count);
        }
        return remainder_calculate(training_set,bags,iteration_count);

    }
    static int unacc_count(List<car> training_set){
        int count=0;
        for(int i=0;i<training_set.size();i++){
            if(training_set.get(i).class_value==1){
                count++;
            }
        }
        return count;
    }
    static int acc_count(List<car> training_set){
        int count=0;
        for(int i=0;i<training_set.size();i++){
            if(training_set.get(i).class_value==2){
                count++;
            }
        }
        return count;
    }
    static int good_count(List<car> training_set){
        int count=0;
        for(int i=0;i<training_set.size();i++){
            if(training_set.get(i).class_value==3){
                count++;
            }
        }
        return count;
    }
    static int vgood_count(List<car> training_set){
        int count=0;
        for(int i=0;i<training_set.size();i++){
            if(training_set.get(i).class_value==4){
                count++;
            }
        }
        return count;
    }
    static int attr_child(int id){
        if(id==1 || id==2 || id==3){
            return 4;
        }

        else{
            return 3;
        }
    }
    static int recurrence(List<car> trainset,tree t){
        int unacc=unacc_count(trainset);
        int acc=acc_count(trainset);
        int good=good_count(trainset);
        int vgood=vgood_count(trainset);
        int total=unacc+acc+good+vgood;
        if(unacc==total || acc ==total || good==total || vgood==total){
            if(unacc==total){
                t.isLeaf=true;
                t.attribute=1;
                return 1;
            }
             
            else if(acc==total){
                t.isLeaf=true;
                t.attribute=2;
                return 2;
            }
            else if(good==total){
                t.isLeaf=true;
                t.attribute=3;
                return 3;
            }
            else {
                t.isLeaf=true;
                t.attribute=4;
                return 4;
            }
            
        }
        node temp=new node();
        double temp_gain;
        for(int i=1;i<=6;i++){
            if(trainset.get(0).attribute_check[i-1]==0){
                temp_gain=child_divide(trainset, i);
//                System.out.println(temp_gain);
                if(temp_gain<temp.gain ){
                    temp.attribute_id=i;
                    temp.gain=temp_gain;
                }
            } 
        }
        int iteration=attr_child(temp.attribute_id);
        int id=temp.attribute_id;
//        System.out.println(id);
        ArrayList[] child_list=new ArrayList[iteration];
        t.attribute=temp.attribute_id;
        for(int r=0;r<iteration;r++) {
            child_list[r]=new ArrayList();
            t.descendent.add(new tree());
        }
        
        for(int i=0;i<iteration;i++) {
            for(var w:trainset) {
                w.attribute_check[id-1]=1;
                if(id==1){
                    if(w.buying==i+1)
                        child_list[i].add(w);
                }

                if(id==2){
                    if(w.maint==i+1)
                        child_list[i].add(w);
                }
                if(id==3){
                    if(w.doors==i+1)
                        child_list[i].add(w);
                }
                if(id==4){
                    if(w.persons==i+1)
                        child_list[i].add(w);
                }
                if(id==5){
                    if(w.lug_boot==i+1)
                        child_list[i].add(w);
                }
                if(id==6){
                    if(w.safety==i+1)
                        child_list[i].add(w);
                }
            }
        }
        for(int y=0;y<child_list.length;y++) {
            if(child_list[y].isEmpty()){
                if(unacc>acc && unacc>good && unacc>vgood) 
                {
                    t.descendent.get(y).isLeaf=true;
                    t.descendent.get(y).attribute=1;
                    return 1;
                }
                else if(acc>unacc && acc>good && acc>vgood) 
                {
                    t.descendent.get(y).isLeaf=true;
                    t.descendent.get(y).attribute=2;
                    return 2;
                }
                else if(good>unacc && good>acc && good>vgood) 
                {
                    t.descendent.get(y).isLeaf=true;
                    t.descendent.get(y).attribute=3;
                    return 3;
                }
                else 
                {
                    t.descendent.get(y).isLeaf=true;
                    t.descendent.get(y).attribute=4;
                    return 4;
                }
            }
            recurrence(child_list[y],t.descendent.get(y));
        }
        //child_divide(trainset,temp.attribute_id);
        return 0;
    }
    static int test(car c,tree t){
        if(t.isLeaf) {
            return t.attribute;
        }
        else{
            switch(t.attribute){
                case 1:
                    return test(c,t.descendent.get(c.buying-1));
                case 2:
                    return test(c,t.descendent.get(c.maint-1));
                case 3:
                    return test(c,t.descendent.get(c.doors-1));
                case 4:
                    return test(c,t.descendent.get(c.persons-1));
                case 5:
                    return test(c,t.descendent.get(c.lug_boot-1));
                case 6:
                    return test(c,t.descendent.get(c.safety-1));
                
            }
        }
        return -1;
    }
    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(new FileInputStream("car.data"));
        int training = (int) ceil(1728 * 0.8);

        car[] dataset = new car[1729];
        for(int i=0;i<=1728;i++)
            dataset[i]=new car();
        List<car> trainset = new ArrayList<>();
        for (int p = 1; p <= 1728; p++) {
            String input = sc.nextLine();
            String[] atr_values = input.split(",");
            dataset[p].buying = buy_value(atr_values[0]);
            dataset[p].maint = maint_value(atr_values[1]);
            dataset[p].doors = doors_value(atr_values[2]);
            dataset[p].persons = persons_value(atr_values[3]);
            dataset[p].lug_boot = lug_boot_value(atr_values[4]);
            dataset[p].safety = safety_value(atr_values[5]);
            dataset[p].class_value = set_class_value(atr_values[6]);
        }
        Random random = new Random(System.nanoTime());
        double[] percentages=new double[20];
        double total=0.0,sqrTotal=0.0;
        for(int i=0;i<20;i++) {
            array = new int[1729];
            for (int p = 1; p <= training; p++) {
                int randomNumber;
                // array[p]=p;
                while (true) {
                    randomNumber = random.nextInt(1728) + 1;
                    if (array[randomNumber] == 0) {
                        array[randomNumber] = 1;
                        break;
                    }
                }
                trainset.add(dataset[randomNumber]);
            }
            tree root = new tree();
            recurrence(trainset, root);
            int correct = 0;
            int incorrect = 0;
            List<car> testset = new ArrayList<>();
            for (int e = 1; e < array.length; e++) {
                if (array[e] == 0)
                    testset.add(dataset[e]);
            }
            for (var c : testset) {
                if (test(c, root) == c.class_value) {
                    correct++;
                } else
                    incorrect++;
            }
            percentages[i]=100.0*correct/(correct+incorrect);
            total+=percentages[i];
            System.out.println("Test "+(i+1)+": correct "+correct +" incorrect "+incorrect +" percentage "+percentages[i]);
            for (int j = 0; j < dataset.length; j++) {
                dataset[j].attribute_check=new int[6];
            }
            trainset.clear();
        }
        System.out.println("Average correctness: "+total/20);
        for(double d:percentages){
            sqrTotal+=(total/20-d)*(total/20-d);
        }
        System.out.println("Standard Deviation: "+((sqrt(sqrTotal/20)<1E-8)?0:sqrt(sqrTotal/20)));
    }
}











// buying=0; // 1=vhigh,2=high,3=med,4=low
// maint=0; //same as buying
// doors=0; //2,3,4,5=more
// persons=0; //2,4, 5=more
// lug_boot=0; //1=small,2=med, 3=big
// safety=0; //1=low,2=med,3=high
// class_value=0;











