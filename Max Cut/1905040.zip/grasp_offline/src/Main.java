import java.io.FileInputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import static java.lang.Thread.sleep;

public class Main{
    static int nodes_num;
    static int node_state[];
    static List<node> left_bag,right_bag;
    static void semi_greedy(node[] nodes,int max,int min,int temp){
        List <node_for_semi> weightlist_left=new ArrayList<>();
        List <node_for_semi> weightlist_right=new ArrayList<>();
        node max_Node_left=new node(max);
        node min_Node_left=new node(min);
        node max_Node_right=new node(max);
        node min_Node_right=new node(min);

        double alpha=Math.random();
        if(temp==1){
            alpha=1;
        }
        

        int count=2;
        while(count<nodes_num){
            int left_weight=0,right_weight=0,highest_left=Integer.MIN_VALUE,highest_right=Integer.MIN_VALUE;
            int lowest_left=Integer.MAX_VALUE,lowest_right=Integer.MAX_VALUE;
            //System.out.println("Iteration inside semi-greedy:"+count);
            for(var a:nodes){
                if(node_state[a.id]!=1 && a.id!=0){
                    for(var b:left_bag){
                        for(var ee:a.adj_list){
                            if(ee.a.id==b.id){
                                left_weight+=ee.weight;
                                break;
                            }
                        }
                    }
                    if(left_weight>highest_left){
                        highest_left=left_weight;
                        max_Node_left=a;
                    }
                    if(left_weight<lowest_left){
                        lowest_left=left_weight;
                        min_Node_left=a;
                    }
                    weightlist_left.add(new node_for_semi(a.id,left_weight));
                    left_weight=0;
                    for(var b:right_bag){
                        for(var ee:a.adj_list){
                            if(ee.a.id==b.id){
                                right_weight+=ee.weight;
                                break;
                            }
                        }
                    }
                    if(right_weight>highest_right){
                        highest_right=right_weight;
                        max_Node_right=a;
                    }
                    if(right_weight<lowest_right){
                        lowest_right=right_weight;
                        min_Node_right=a;
                    }
                    weightlist_right.add(new node_for_semi(a.id, right_weight));
                    right_weight=0;
                }

            }
            if(highest_left>=highest_right){
                max=highest_left;
            }
            else{
                max=highest_right;
            }
            if(lowest_left<=lowest_right){
                min=lowest_left;
            }
            else{
                min=lowest_right;
            }
            double weight=min+alpha*(max-min);
            List<node_for_semi> selection=new ArrayList<>();
            for(var p:weightlist_left){
                if(p.weight>=weight){
                    p.side=0;
                    selection.add(p);
                }
            }
            weightlist_left.clear();
            for(var p:weightlist_right){
                if(p.weight>=weight){
                    p.side=1;
                    selection.add(p);
                }
            }
            weightlist_right.clear();
            Random rand=new Random();
            int random_index=rand.nextInt(selection.size());
            random_index=Math.abs(random_index);
            random_index=random_index%selection.size();
            node_for_semi rr=selection.get(random_index);
            if(rr.side==0){
                right_bag.add(nodes[rr.id]);
            }
            else{
                left_bag.add(nodes[rr.id]);

            }

            node_state[rr.id]=1;
            count++;
        }

    }
    static void local_search(){
        int temp_weight=0;
        List<node> temp_left=new ArrayList<>();
        List<node> temp_right=new ArrayList<>();
        for(var i:left_bag){
            for(var j:right_bag){
                for(var ee:i.adj_list){
                    if(ee.a.id==j.id){
                        temp_weight+=ee.weight;
                        break;
                    }
                }
            }
            for(var j:left_bag){
                for(var ee:i.adj_list){
                    if(ee.a.id==j.id){
                        temp_weight-=ee.weight;
                        break;
                    }
                }
                
            }
            if(temp_weight<0){
                temp_left.add(i);
            }
            temp_weight=0;
        }
        for(var i:right_bag){
            for(var j:left_bag){
                for(var ee:i.adj_list){
                    if(ee.a.id==j.id){
                        temp_weight+=ee.weight;
                        break;
                    }
                }
            }
            for(var j:right_bag){
                for(var ee:i.adj_list){
                    if(ee.a.id==j.id){
                        temp_weight-=ee.weight;
                        break;
                    }
                }
                
            }
            if(temp_weight<0){
                temp_right.add(i);
            }
            temp_weight=0;
        }
        for(var i:temp_left){
            left_bag.remove(i);
            right_bag.add(i);
        }
        for(var i:temp_right){
            right_bag.remove(i);
            left_bag.add(i);
        }    
    }
    
    public static void main(String[] args) throws Exception {
        Scanner sc=new Scanner(System.in);

        String filename=sc.nextLine();

            InputStream input_file = new FileInputStream(filename);
            PrintStream output_file = new PrintStream("output.txt");
            System.setOut(output_file);
            System.out.println("Problem File:"+filename);
            left_bag = new ArrayList<>();
            right_bag = new ArrayList<>();
            int vertices, edges_num, max_s = 0, max_f = 0, max_w;
            int min_s = 0, min_f = 0, min_w;
            max_w = Integer.MIN_VALUE;
            min_w = Integer.MAX_VALUE;
            sc = new Scanner(input_file);
            vertices = sc.nextInt();
            nodes_num = vertices;
            edges_num = sc.nextInt();
            node[] nodes = new node[vertices + 1];
            node_state = new int[vertices + 1];
            for (int i = 0; i <= vertices; i++) {
                nodes[i] = new node(i);
            }
            for (int i = 0; i < edges_num; i++) {
                int s, f, w;
                s = sc.nextInt();
                f = sc.nextInt();
                w = sc.nextInt();
                nodes[s].adj_list.add(new adjacency_node(nodes[f], w));
                nodes[f].adj_list.add(new adjacency_node(nodes[s], w));
                if (w > max_w) {
                    max_s = s;
                    max_f = f;
                }
                if (w < min_w) {
                    min_s = s;
                    min_f = f;
                }
            }
            left_bag.add(nodes[max_s]);
            right_bag.add(nodes[max_f]);
            node_state[max_s] = 1;
            node_state[max_f] = 1;
            int count = 0, max_weight = 0,total_weight=0;
            while (count < 20) {
                semi_greedy(nodes, max_w, min_w, 0);
                local_search();
                int weight = 0;
                for (var a : left_bag) {
                    for (var b : right_bag) {
                        for (var ee : a.adj_list) {
                            if (ee.a.id == b.id) {
                                weight += ee.weight;
                                break;
                            }
                        }
                    }
                }
                total_weight+=weight;
                if (weight > max_weight) {
                    max_weight = weight;
                }
                count++;
                left_bag.clear();
                right_bag.clear();
                left_bag.add(nodes[max_s]);
                right_bag.add(nodes[max_f]);

//            max_weight=0;
                for (int pp = 0; pp <= nodes_num; pp++) {
                    node_state[pp] = 0;
                }
                node_state[max_s] = 1;
                node_state[max_f] = 1;
            }
            System.out.println("Grasp solution:" + max_weight);


            // now for the greedy solution
            left_bag.clear();
            right_bag.clear();
            left_bag.add(nodes[max_s]);
            right_bag.add(nodes[max_f]);
            node_state[max_s] = 1;
            node_state[max_f] = 1;
            count = 0;
            max_weight = 0;
            while (count < 1) {
                semi_greedy(nodes, max_w, min_w, 1);
                local_search();
                int weight = 0;
                for (var a : left_bag) {
                    for (var b : right_bag) {
                        for (var ee : a.adj_list) {
                            if (ee.a.id == b.id) {
                                weight += ee.weight;
                                break;
                            }
                        }
                    }
                }
                if (weight > max_weight) {
                    max_weight = weight;
                }
                count++;
                left_bag.clear();
                right_bag.clear();
                left_bag.add(nodes[max_s]);
                right_bag.add(nodes[max_f]);

//            max_weight=0;
                for (int pp = 0; pp <= nodes_num; pp++) {
                    node_state[pp] = 0;
                }
                node_state[max_s] = 1;
                node_state[max_f] = 1;
            }
            System.out.println("Greedy solution:" + max_weight);
            filename= sc.nextLine();


    }
}
class edge{
    int start;
    int end;
    int weight;
    edge(int s,int f,int w){
        start=s;
        end=f;
        weight=w;
    }
}
class adjacency_node{
    node a;
    int weight;
    adjacency_node(node i,int w){
        a=i;
        weight=w;
    }
}
class node{
    int id;
    List<adjacency_node> adj_list=new ArrayList<>();
    node(int i){
        id=i;
    }
}
class node_for_semi{
    int id;
    int weight;
    int side; // 0 for weightlist_left,1 for right weightlist
    node_for_semi(int i,int w){
        id=i;
        weight=w;
        
    }
}